from django.apps import AppConfig


class MachinelearndemoConfig(AppConfig):
    name = 'MachineLearnDemo'
