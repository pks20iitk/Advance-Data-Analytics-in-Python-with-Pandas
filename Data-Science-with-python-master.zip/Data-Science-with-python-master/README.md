# Data-Science-with-python
This repo has all the required materials of the Data science with python video series.


The youtube channel: https://www.youtube.com/channel/UCKXQTY--Ha6_aT8zKxQ0rGw

Please subscribe to my channel by clicking on the link: https://www.youtube.com/channel/UCKXQTY--Ha6_aT8zKxQ0rGw?sub_confirmation=1
